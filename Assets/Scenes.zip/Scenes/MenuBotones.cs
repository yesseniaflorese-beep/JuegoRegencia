using UnityEngine;
 
/// <summary>
/// Agrega este componente a cualquier GameObject existente en la escena del menú
/// (Canvas, cámara, etc). Úsalo como puente para los botones de UI.
/// </summary>
public class MenuBotones: MonoBehaviour
{
    public void GoToCredits()
    {
        SceneController.instance.LoadCredits();
    }
 
    public void GoToNewGame()
    {
        SceneController.instance.StartGame();
    }
 
    public void GoToInstrucciones()
    {
        SceneController.instance.LoadInstrucciones();
    }
}